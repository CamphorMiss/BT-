#define _CRT_SECURE_NO_WARNINGS 1


#include "stack.h"

int main()
{
	TestStack();
	system("pause");
	return 0;
}