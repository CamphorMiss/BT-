#define _CRT_SECURE_NO_WARNINGS 1


#include "Slist.h"

int main()
{
	SList pr;
    TEST1(&pr);
	system("pause");
	return 0;
}